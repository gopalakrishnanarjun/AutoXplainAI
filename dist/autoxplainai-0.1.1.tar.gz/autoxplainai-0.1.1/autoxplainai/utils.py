def preprocess_data(data):
    # Add preprocessing logic here
    return data